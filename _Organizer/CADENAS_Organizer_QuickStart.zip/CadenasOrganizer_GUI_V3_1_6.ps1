﻿# CADENAS NX File Organizer V3.1.6
# Metadata-driven organizer. Uses PartInfo metadata (NB + ProjectPath) to map
# flat Members .prt files to the exact CADENAS catalog component folder.
# Safe behavior: preview/log matching first; never overwrite; ambiguous matches are skipped.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$ErrorActionPreference = 'Stop'

$DefaultSource = Join-Path $env:LOCALAPPDATA 'CADENAS Library\Members\gb_standards'
$ConfigDir = Join-Path $env:USERPROFILE 'Documents\CADENAS_Organizer'
$ConfigPath = Join-Path $ConfigDir 'config.json'
$LogPath = Join-Path $ConfigDir 'Organizer_Log.txt'
if (-not (Test-Path -LiteralPath $ConfigDir)) {
    New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null
}
$config = @{ Source = $DefaultSource; Target = '' }
if (Test-Path -LiteralPath $ConfigPath) {
    try {
        $loaded = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
        if ($loaded.Source) { $config.Source = [string]$loaded.Source }
        if ($loaded.Target) { $config.Target = [string]$loaded.Target }
    } catch { }
}

function Save-Config {
    @{ Source = $sourceText.Text.Trim(); Target = $targetText.Text.Trim() } |
        ConvertTo-Json | Set-Content -LiteralPath $ConfigPath -Encoding UTF8
}
function Write-Log {
    param([string]$Message, [string]$Color = 'Black')
    $line = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $Message"
    $script:LogBox.SelectionStart = $script:LogBox.TextLength
    $script:LogBox.SelectionLength = 0
    $script:LogBox.SelectionColor = [System.Drawing.Color]::FromName($Color)
    $script:LogBox.AppendText($line + [Environment]::NewLine)
    $script:LogBox.SelectionColor = $script:LogBox.ForeColor
    Add-Content -LiteralPath $LogPath -Value $line
    [System.Windows.Forms.Application]::DoEvents()
}
function Normalize-Name {
    param([string]$Text)
    if ($null -eq $Text) { return '' }
    $v = $Text -replace '(?i)_PART\d+$', ''
    $v = $v -replace '[^A-Za-z0-9]+', ' '
    return (($v.Trim() -replace '\s+', ' ').ToLowerInvariant())
}
function Get-GroupName {
    param([string]$BaseName)
    return ($BaseName -replace '(?i)_PART\d+$', '')
}
function Browse-Folder {
    param([string]$Description, [string]$CurrentPath)
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = $Description
    $dialog.ShowNewFolderButton = $false
    if (-not [string]::IsNullOrWhiteSpace($CurrentPath) -and
        (Test-Path -LiteralPath $CurrentPath -PathType Container)) {
        $dialog.SelectedPath = $CurrentPath
    }
    if ($dialog.ShowDialog($script:MainForm) -eq [System.Windows.Forms.DialogResult]::OK) {
        return $dialog.SelectedPath
    }
    return $null
}

# Read PartInfo metadata recursively. A catalog folder can contain PartInfo.txt
# or a file named simply PartInfo (Windows may hide the .txt extension).
function Get-CatalogMappings {
    param([string]$TargetRoot)
    $records = New-Object System.Collections.Generic.List[object]
    $metadataFiles = @(Get-ChildItem -LiteralPath $TargetRoot -File -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '(?i)^PartInfo(?:\.txt)?$' })
    foreach ($meta in $metadataFiles) {
        try {
            $raw = Get-Content -LiteralPath $meta.FullName -Raw
            $data = $raw | ConvertFrom-Json
            $entries = @()
            if ($data.PartInfos) { $entries = @($data.PartInfos) }
            elseif ($data.NB -or $data.ProjectPath) { $entries = @($data) }
            foreach ($entry in $entries) {
                $nb = [string]$entry.NB
                $project = [string]$entry.ProjectPath
                if ([string]::IsNullOrWhiteSpace($project) -and $data.ProjectPath) {
                    $project = [string]$data.ProjectPath
                }
                if ([string]::IsNullOrWhiteSpace($nb) -or [string]::IsNullOrWhiteSpace($project)) { continue }

                # ProjectPath commonly ends with a .prj filename, while the
                # actual NX destination is a folder named after that project.
                # Example:
                # gb_standards/bearings/gb_t_5800_1_2012/gb_t_5800_1_2012.prj
                # must resolve to:
                # <TargetRoot>\gb_t_5800_1_2012\gb_t_5800_1_2012
                $parts = @(
                    $project -split '[/\\]' |
                    Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
                )
                $categoryName = (Get-Item -LiteralPath $TargetRoot).Name
                $catIndex = -1
                for ($i = 0; $i -lt $parts.Count; $i++) {
                    if ([string]::Equals([string]$parts[$i], [string]$categoryName,
                        [StringComparison]::OrdinalIgnoreCase)) {
                        $catIndex = $i
                    }
                }

                $dest = $null
                if ($catIndex -ge 0 -and $catIndex -lt ($parts.Count - 1)) {
                    $dest = $TargetRoot

                    # Add intermediate directory segments after category,
                    # excluding the final .prj filename.
                    for ($i = $catIndex + 1; $i -lt ($parts.Count - 1); $i++) {
                        $segment = [string]$parts[$i]
                        if ($segment -eq '.' -or $segment -eq '..' -or
                            $segment -match '[:*?"<>|]') {
                            $dest = $null
                            break
                        }
                        $dest = Join-Path $dest $segment
                    }

                    # The .prj filename stem is itself the final component folder.
                    if ($dest) {
                        $projectFile = [string]$parts[$parts.Count - 1]
                        $projectStem = [IO.Path]::GetFileNameWithoutExtension($projectFile)
                        if ([string]::IsNullOrWhiteSpace($projectStem) -or
                            $projectStem -match '[:*?"<>|]' -or
                            $projectStem -eq '.' -or $projectStem -eq '..') {
                            $dest = $null
                        }
                        else {
                            $dest = Join-Path $dest $projectStem
                        }
                    }
                }

                # Use metadata's own directory only when it exactly matches
                # the fully resolved expected destination. Never fall back
                # to its parent folder, which caused the previous misplacement.
                if ($dest -and -not (Test-Path -LiteralPath $dest -PathType Container)) {
                    if ([string]::Equals(
                        [IO.Path]::GetFullPath($meta.Directory.FullName).TrimEnd('\'),
                        [IO.Path]::GetFullPath($dest).TrimEnd('\'),
                        [StringComparison]::OrdinalIgnoreCase)) {
                        $dest = $meta.Directory.FullName
                    }
                }
                if ($dest -and -not (Test-Path -LiteralPath $dest -PathType Container)) {
                    Write-Log "UNRESOLVED destination for NB '$nb'. ProjectPath='$project'; Expected='$dest'" 'DarkOrange'
                    $dest = $null
                }
                if ($dest -and (Test-Path -LiteralPath $dest -PathType Container)) {
                    $records.Add([pscustomobject]@{
                        NB = $nb
                        Key = (Normalize-Name $nb)
                        ProjectPath = $project
                        Destination = $dest
                        Metadata = $meta.FullName
                    })
                }
            }
        } catch {
            Write-Log "Could not parse metadata '$($meta.FullName)': $($_.Exception.Message)" 'DarkOrange'
        }
    }
    # Return the List contents as a plain object[]; avoid PowerShell 5.1's
    # collection adapter issue with @($genericList), which can throw
    # System.ArgumentException: "Argument types do not match".
    return $records.ToArray()
}

# Main window
$script:MainForm = New-Object System.Windows.Forms.Form
$script:MainForm.Text = 'CADENAS Organizer V3.1.6 - Metadata Matching + Folder Checker'
$script:MainForm.Size = New-Object System.Drawing.Size(900, 690)
$script:MainForm.MinimumSize = New-Object System.Drawing.Size(900, 690)
$script:MainForm.StartPosition = 'CenterScreen'
$script:MainForm.Font = New-Object System.Drawing.Font('Segoe UI', 9)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'CADENAS NX File Organizer V3.1.6'
$title.Font = New-Object System.Drawing.Font('Segoe UI', 15, [System.Drawing.FontStyle]::Bold)
$title.Location = New-Object System.Drawing.Point(20, 16)
$title.Size = New-Object System.Drawing.Size(800, 32)
$script:MainForm.Controls.Add($title)

$srcLabel = New-Object System.Windows.Forms.Label
$srcLabel.Text = 'Source Members folder containing downloaded NX .prt files:'
$srcLabel.Location = New-Object System.Drawing.Point(22, 62)
$srcLabel.Size = New-Object System.Drawing.Size(650, 22)
$script:MainForm.Controls.Add($srcLabel)
$sourceText = New-Object System.Windows.Forms.TextBox
$sourceText.Text = $config.Source
$sourceText.Location = New-Object System.Drawing.Point(22, 86)
$sourceText.Size = New-Object System.Drawing.Size(735, 25)
$sourceText.Anchor = 'Top,Left,Right'
$script:MainForm.Controls.Add($sourceText)
$srcBrowse = New-Object System.Windows.Forms.Button
$srcBrowse.Text = 'Browse...'
$srcBrowse.Location = New-Object System.Drawing.Point(767, 84)
$srcBrowse.Size = New-Object System.Drawing.Size(105, 29)
$srcBrowse.Anchor = 'Top,Right'
$script:MainForm.Controls.Add($srcBrowse)

$tgtLabel = New-Object System.Windows.Forms.Label
$tgtLabel.Text = 'Target catalog category folder (e.g. gb_standards\bearings):'
$tgtLabel.Location = New-Object System.Drawing.Point(22, 127)
$tgtLabel.Size = New-Object System.Drawing.Size(650, 22)
$script:MainForm.Controls.Add($tgtLabel)
$targetText = New-Object System.Windows.Forms.TextBox
$targetText.Text = $config.Target
$targetText.Location = New-Object System.Drawing.Point(22, 151)
$targetText.Size = New-Object System.Drawing.Size(735, 25)
$targetText.Anchor = 'Top,Left,Right'
$script:MainForm.Controls.Add($targetText)
$tgtBrowse = New-Object System.Windows.Forms.Button
$tgtBrowse.Text = 'Browse...'
$tgtBrowse.Location = New-Object System.Drawing.Point(767, 149)
$tgtBrowse.Size = New-Object System.Drawing.Size(105, 29)
$tgtBrowse.Anchor = 'Top,Right'
$script:MainForm.Controls.Add($tgtBrowse)

$hint = New-Object System.Windows.Forms.Label
$hint.Text = 'V3.1.6: recursively checks TXT/PS3 NB metadata against .prt files inside the selected catalog folder only.'
$hint.ForeColor = [System.Drawing.Color]::DimGray
$hint.Location = New-Object System.Drawing.Point(22, 184)
$hint.Size = New-Object System.Drawing.Size(840, 22)
$script:MainForm.Controls.Add($hint)

$processButton = New-Object System.Windows.Forms.Button
$processButton.Text = 'Analyze and move matched files'
$processButton.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
$processButton.Location = New-Object System.Drawing.Point(22, 218)
$processButton.Size = New-Object System.Drawing.Size(260, 40)
$script:MainForm.Controls.Add($processButton)
$checkButton = New-Object System.Windows.Forms.Button
$checkButton.Text = 'Check Folders'
$checkButton.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
$checkButton.Location = New-Object System.Drawing.Point(415, 218)
$checkButton.Size = New-Object System.Drawing.Size(180, 40)
$script:MainForm.Controls.Add($checkButton)
$clearButton = New-Object System.Windows.Forms.Button
$clearButton.Text = 'Clear log'
$clearButton.Location = New-Object System.Drawing.Point(295, 223)
$clearButton.Size = New-Object System.Drawing.Size(100, 30)
$script:MainForm.Controls.Add($clearButton)
$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = 'Ready'
$statusLabel.Location = New-Object System.Drawing.Point(610, 226)
$statusLabel.Size = New-Object System.Drawing.Size(255, 25)
$statusLabel.ForeColor = [System.Drawing.Color]::DarkGreen
$script:MainForm.Controls.Add($statusLabel)

$logLabel = New-Object System.Windows.Forms.Label
$logLabel.Text = 'Activity log:'
$logLabel.Location = New-Object System.Drawing.Point(22, 272)
$logLabel.Size = New-Object System.Drawing.Size(150, 22)
$script:MainForm.Controls.Add($logLabel)
$script:LogBox = New-Object System.Windows.Forms.RichTextBox
$script:LogBox.Location = New-Object System.Drawing.Point(22, 297)
$script:LogBox.Size = New-Object System.Drawing.Size(850, 330)
$script:LogBox.Anchor = 'Top,Bottom,Left,Right'
$script:LogBox.ReadOnly = $true
$script:LogBox.Font = New-Object System.Drawing.Font('Consolas', 9)
$script:MainForm.Controls.Add($script:LogBox)

$srcBrowse.Add_Click({
    $chosen = Browse-Folder 'Select the Members folder containing downloaded NX .prt files' $sourceText.Text
    if ($chosen) { $sourceText.Text = $chosen; Save-Config }
})
$tgtBrowse.Add_Click({
    $chosen = Browse-Folder 'Select the target catalog category folder' $targetText.Text
    if ($chosen) { $targetText.Text = $chosen; Save-Config }
})
$sourceText.Add_Leave({ Save-Config })
$targetText.Add_Leave({ Save-Config })
$clearButton.Add_Click({ $script:LogBox.Clear() })

# Read-only integrity check: scan every descendant component folder. Each folder's
# TXT (NB field) or PS3 (NB attribute) identifies the expected NX file.
# The matching .prt is searched recursively inside the selected catalog folder only.
function Get-ComponentNBFromMetadata {
    param([string]$FolderPath)
    $names = New-Object System.Collections.Generic.List[string]

    # PartInfo.txt is the primary source. Also accept other .txt files that
    # expose an NB property, because CADENAS installations can vary by catalog.
    $txtFiles = @(Get-ChildItem -LiteralPath $FolderPath -File -ErrorAction Stop |
        Where-Object { $_.Extension -ieq '.txt' -or $_.Name -ieq 'PartInfo' })
    foreach ($txt in $txtFiles) {
        try {
            $raw = Get-Content -LiteralPath $txt.FullName -Raw -ErrorAction Stop
            try {
                $obj = $raw | ConvertFrom-Json -ErrorAction Stop
                if ($obj.NB) { $names.Add(([string]$obj.NB).Trim()) }
                foreach ($entry in @($obj.PartInfos)) {
                    if ($entry -and $entry.NB) { $names.Add(([string]$entry.NB).Trim()) }
                }
            } catch {
                $m = [regex]::Match($raw, '(?is)\bNB\s*[=:]\s*["''](?<v>[^"'']+)["'']')
                if ($m.Success) { $names.Add($m.Groups['v'].Value.Trim()) }
            }
        } catch { }
    }

    # PS3 files commonly store the component name in an NB attribute.
    $ps3Files = @(Get-ChildItem -LiteralPath $FolderPath -File -Filter '*.ps3' -ErrorAction Stop)
    foreach ($ps3 in $ps3Files) {
        try {
            $raw = Get-Content -LiteralPath $ps3.FullName -Raw -ErrorAction Stop
            $matches = [regex]::Matches($raw, '(?is)\bNB\s*[=:]\s*["''](?<v>[^"'']+)["'']')
            foreach ($m in $matches) { $names.Add($m.Groups['v'].Value.Trim()) }
            if ($matches.Count -eq 0) {
                $m = [regex]::Match($raw, '(?is)<NB>\s*(?<v>.*?)\s*</NB>')
                if ($m.Success) { $names.Add($m.Groups['v'].Value.Trim()) }
            }
        } catch { }
    }

    return @($names | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
}

$checkButton.Add_Click({
    $catalogRoot = $targetText.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($catalogRoot) -or
        -not (Test-Path -LiteralPath $catalogRoot -PathType Container)) {
        [System.Windows.Forms.MessageBox]::Show('Select an existing target catalog folder.', 'Catalog folder required') | Out-Null
        return
    }

    Save-Config
    $checkButton.Enabled = $false
    $processButton.Enabled = $false
    $statusLabel.Text = 'Checking folders and NX files...'
    Write-Log "Starting recursive TXT/PS3-based NX file check: $catalogRoot" 'Blue'
    Write-Log 'PRT lookup scope: selected catalog folder and all of its nested subdirectories only.' 'Blue'
    $passed = 0; $missing = 0; $skipped = 0; $checkErrors = 0
    try {
        # Build a case-insensitive lookup of every .prt filename within the selected
        # checking folder. No external Members/source folder is used by this check.
        $prtNames = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
        $prtFiles = @(Get-ChildItem -LiteralPath $catalogRoot -File -Filter '*.prt' -Recurse -ErrorAction Stop)
        foreach ($prt in $prtFiles) { [void]$prtNames.Add($prt.Name) }
        Write-Log "NX .prt files found inside selected folder: $($prtFiles.Count)" 'Blue'

        $folders = @(Get-ChildItem -LiteralPath $catalogRoot -Directory -Recurse -ErrorAction Stop |
            Sort-Object FullName)
        Write-Log "Subdirectories discovered: $($folders.Count)" 'Blue'

        foreach ($folder in $folders) {
            try {
                $nbNames = @(Get-ComponentNBFromMetadata -FolderPath $folder.FullName)
                if ($nbNames.Count -eq 0) {
                    # Container folders without TXT/PS3 NB metadata are intentionally skipped.
                    $skipped++
                    continue
                }

                $matchedNames = New-Object System.Collections.Generic.List[string]
                foreach ($nb in $nbNames) {
                    $expectedFile = $nb + '.prt'
                    if ($prtNames.Contains($expectedFile)) {
                        $matchedNames.Add($expectedFile)
                    }
                }

                if ($matchedNames.Count -gt 0) {
                    # Successful folders are counted but intentionally omitted from the Activity Log.
                    $passed++
                } else {
                    Write-Log "MISSING: $($folder.FullName) - expected .prt file(s) inside selected folder: $(($nbNames | ForEach-Object { $_ + '.prt' }) -join '; ')" 'Red'
                    $missing++
                }
            } catch {
                Write-Log "CHECK ERROR: $($folder.FullName) - $($_.Exception.Message)" 'Red'
                $checkErrors++
            }
        }
        Write-Log "Recursive check finished. PASS: $passed; missing PRT: $missing; skipped folders without TXT/PS3 NB metadata: $skipped; errors: $checkErrors." 'Blue'
        $statusLabel.Text = "Check complete - PASS $passed | Missing $missing | Skipped $skipped | Errors $checkErrors"
    } catch {
        Write-Log "Recursive check failed: $($_.Exception.Message)" 'Red'
        $statusLabel.Text = 'Check failed - see log'
    } finally {
        $checkButton.Enabled = $true
        $processButton.Enabled = $true
    }
})

$processButton.Add_Click({
    $sourceRoot = $sourceText.Text.Trim()
    $targetRoot = $targetText.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($sourceRoot) -or
        -not (Test-Path -LiteralPath $sourceRoot -PathType Container)) {
        [System.Windows.Forms.MessageBox]::Show('Select an existing source folder.', 'Source folder required') | Out-Null
        return
    }
    if ([string]::IsNullOrWhiteSpace($targetRoot) -or
        -not (Test-Path -LiteralPath $targetRoot -PathType Container)) {
        [System.Windows.Forms.MessageBox]::Show('Select an existing target category folder.', 'Target folder required') | Out-Null
        return
    }
    Save-Config
    $processButton.Enabled = $false
    $statusLabel.Text = 'Reading metadata...'
    Write-Log "Source: $sourceRoot" 'Blue'
    Write-Log "Target category: $targetRoot" 'Blue'
    $moved = 0; $skipped = 0; $errors = 0
    try {
        $mappings = @(Get-CatalogMappings -TargetRoot $targetRoot)
        Write-Log "Catalog metadata records loaded: $($mappings.Count)" 'Blue'
        if ($mappings.Count -eq 0) {
            Write-Log 'No usable PartInfo metadata was found under the target category. No files were moved.' 'DarkOrange'
            $statusLabel.Text = 'No metadata found'
            return
        }

        # Only direct .prt files in the selected source folder are considered.
        $prtFiles = @(Get-ChildItem -LiteralPath $sourceRoot -File -Filter '*.prt')
        if ($prtFiles.Count -eq 0) {
            Write-Log 'No .prt files found directly in the source folder.' 'DarkOrange'
            $statusLabel.Text = 'No NX files found'
            return
        }

        $groups = @($prtFiles | Group-Object { Get-GroupName $_.BaseName })
        foreach ($group in $groups) {
            $componentName = [string]$group.Name
            $key = Normalize-Name $componentName
            $matches = @($mappings | Where-Object { $_.Key -eq $key } |
                Sort-Object Destination, ProjectPath -Unique)

            if ($matches.Count -eq 0) {
                Write-Log "SKIP: No PartInfo NB match for '$componentName'." 'DarkOrange'
                $skipped++
                continue
            }
            $destinations = @($matches | Select-Object -ExpandProperty Destination -Unique)
            if ($destinations.Count -ne 1) {
                Write-Log "SKIP: '$componentName' matches multiple catalog destinations: $($destinations -join '; ')" 'DarkOrange'
                $skipped++
                continue
            }
            $destination = $destinations[0]
            if (-not (Test-Path -LiteralPath $destination -PathType Container)) {
                Write-Log "SKIP: Destination does not exist: $destination" 'DarkOrange'
                $skipped++
                continue
            }

            # Preflight the whole group: do not partially move a family if any
            # destination filename already exists or a source file is unavailable.
            $conflict = $false
            foreach ($file in $group.Group) {
                $destFile = Join-Path $destination $file.Name
                if (Test-Path -LiteralPath $destFile) {
                    Write-Log "SKIP: Destination file already exists: $destFile" 'DarkOrange'
                    $conflict = $true
                }
                try {
                    $stream = [IO.File]::Open($file.FullName, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
                    $stream.Close()
                } catch {
                    Write-Log "SKIP: Source file is locked or inaccessible: $($file.FullName)" 'DarkOrange'
                    $conflict = $true
                }
            }
            if ($conflict) { $skipped++; continue }

            try {
                foreach ($file in $group.Group) {
                    Move-Item -LiteralPath $file.FullName -Destination (Join-Path $destination $file.Name) -ErrorAction Stop
                    Write-Log "MOVED: $($file.Name) -> $destination" 'DarkGreen'
                    $moved++
                }
            } catch {
                Write-Log "ERROR moving group '$componentName': $($_.Exception.Message)" 'Red'
                $errors++
            }
        }
        Write-Log "Finished. Files moved: $moved; groups skipped: $skipped; errors: $errors." 'Blue'
        $statusLabel.Text = "Finished - moved $moved file(s), skipped $skipped group(s), errors $errors"
    } catch {
        $err = $_
        Write-Log "FATAL ERROR TYPE: $($err.Exception.GetType().FullName)" 'Red'
        Write-Log "FATAL ERROR: $($err.Exception.Message)" 'Red'
        Write-Log "SCRIPT LINE: $($err.InvocationInfo.ScriptLineNumber)" 'Red'
        Write-Log "STATEMENT: $($err.InvocationInfo.Line)" 'Red'
        Write-Log "POSITION: $($err.InvocationInfo.PositionMessage)" 'Red'
        Write-Log "STACK: $($err.ScriptStackTrace)" 'Red'
        $statusLabel.Text = 'Error - see log'
    } finally {
        $processButton.Enabled = $true
    }
})
$script:MainForm.Add_Shown({ Write-Log 'Ready. V3.1.6 checks TXT/PS3 NB references against .prt files found only inside the selected catalog folder and its nested subdirectories.' 'Blue' })
[void]$script:MainForm.ShowDialog()
